def func1(x1,x2):
    print(x1+x2)


func1(1,2)


