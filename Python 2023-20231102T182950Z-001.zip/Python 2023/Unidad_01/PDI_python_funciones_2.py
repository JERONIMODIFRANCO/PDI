import sys
def func1(x1=1,x2=10):
    print(x1+x2)

if __name__=="__main__":
    func1(10,20)
    # func1(int(sys.argv[1]), int(sys.argv[2]))


